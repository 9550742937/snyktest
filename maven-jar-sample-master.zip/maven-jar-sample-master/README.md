# maven-jar-sample
Project to create an executable jar file with maven

# Reference
https://www.yhayashi30.org/java/maven-create-jar-file/